﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FrontToBack.DAL;
using FrontToBack.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace FrontToBack.Controllers
{
    public class ProductController : Controller
    {
        private readonly AppDbContext _db;
        public ProductController(AppDbContext db)
        {
            _db = db;
        }
        public IActionResult Index(int? page)
        {
            ViewBag.Page = page;
            ViewBag.PageCount =Math.Ceiling((decimal)_db.Products.Count() / 12);
            ViewBag.ProductCount = _db.Products.Count();
            if (page == null)
            {
                return View(_db.Products.Select(p => new ProductVM
                {
                    Id = p.Id,
                    Price = p.Price,
                    Title = p.Title,
                    Category = p.Category,
                    Image = p.Image
                }).Take(12));
            }
            else
            {
                return View(_db.Products.Select(p => new ProductVM
                {
                    Id = p.Id,
                    Price = p.Price,
                    Title = p.Title,
                    Category = p.Category,
                    Image = p.Image
                }).Skip(((int)page-1)*12).Take(12));
            }
            
        }

        public IActionResult Load(int skip)
        {
            var model = _db.Products.Select(p => new ProductVM
            {
                Id = p.Id,
                Price = p.Price,
                Title = p.Title,
                Category = p.Category,
                Image = p.Image
            }).Skip(skip).Take(8);
            return PartialView("_ProductPartial", model);
            #region OldVersion
            //return Json(_db.Products.Select(p => new ProductVM
            //{
            //    Id = p.Id,
            //    Price = p.Price,
            //    Title = p.Title,
            //    Category = p.Category,
            //    Image = p.Image
            //}).Skip(8).Take(8));
            #endregion

        }
    }
}