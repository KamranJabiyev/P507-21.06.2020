﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FrontToBack.DAL;
using FrontToBack.Models;
using FrontToBack.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace FrontToBack.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _db;
        public HomeController(AppDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            //HttpContext.Session.SetString("group", "p507");
            //Response.Cookies.Append("name", "Mubush", new CookieOptions { MaxAge = TimeSpan.FromMinutes(20) });
            //string cookie = Request.Cookies["name"];
            //string session = HttpContext.Session.GetString("group");
            HomeVM model = new HomeVM()
            {
                Sliders = _db.Sliders,
                Content = _db.Contents.FirstOrDefault(),
                Categories = _db.Categories
            };
            return View(model);
        }

        public async Task<IActionResult> AddBasket(int? id)
        {
            if (id == null) return NotFound();
            Product product =await _db.Products.FindAsync(id);
            if (product == null) return NotFound();

            List<ProductBasketVM> products;
            string existBasket = Request.Cookies["basket"];
            if (existBasket == null)
            {
                products = new List<ProductBasketVM>();
            }
            else
            {
                products = JsonConvert.DeserializeObject<List<ProductBasketVM>>(existBasket);
            }

            ProductBasketVM checkPro = products.FirstOrDefault(p=>p.Id==id);

            if (checkPro == null)
            {
                ProductBasketVM newPro = new ProductBasketVM
                {
                    Id = product.Id,
                    Image = product.Image,
                    Title = product.Title,
                    Price = product.Price,
                    Count = 1
                };
                products.Add(newPro);
            }
            else
            {
                checkPro.Count++;
            }
            
            string basket = JsonConvert.SerializeObject(products);
            Response.Cookies.Append("basket", basket, new CookieOptions { MaxAge = TimeSpan.FromDays(14) });
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Basket()
        {
            
            return Content(Request.Cookies["basket"]);
        }
    }
}